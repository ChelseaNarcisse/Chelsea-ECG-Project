"""Train the two waveform models (Kaggle "ECG Heartbeat Categorization" data).

Run from the repository root:   python training/train_waveform_models.py

Inputs : data/raw/waveform/mitbih_train.csv, mitbih_test.csv   (arrhythmia, 5 classes)
         data/raw/waveform/ptbdb_normal.csv, ptbdb_abnormal.csv (myocardial infarction)
Outputs: backend/models/waveform_<task>_<model>.pkl
         backend/models/waveform_metrics.json
         frontend/sample_data/waveform/*.csv   (demo upload files)

Evaluation note: the Kaggle files only provide a random, beat-level split
(no patient ids), so beats of one patient can appear in both train and
test. These scores are therefore optimistic compared with the
inter-patient evaluation of the feature-based model; the report says so.
"""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, classification_report,
                             confusion_matrix, f1_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from cardio_ml.waveform import (  # noqa: E402
    RAW_WAVE_COLUMNS, TASKS, WAVE_ENGINEERED_COLUMNS, WAVE_MODEL_COLUMNS, engineer_waveform_features,
)

RANDOM_STATE = 42
DATA_DIR = ROOT / "data" / "raw" / "waveform"
MODEL_DIR = ROOT / "backend" / "models"
SAMPLE_DIR = ROOT / "frontend" / "sample_data" / "waveform"


def make_models() -> dict:
    return {
        "logistic": ("Logistic Regression", Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=2000, class_weight="balanced", C=0.5))])),
        "hgb": ("Gradient Boosting (HistGB)", Pipeline([
            ("clf", HistGradientBoostingClassifier(
                max_iter=400, learning_rate=0.1, max_leaf_nodes=63, l2_regularization=1.0,
                class_weight="balanced", random_state=RANDOM_STATE))])),
    }


def evaluate(y_true, y_pred, proba, classes, normal) -> dict:
    report = classification_report(y_true, y_pred, labels=classes, output_dict=True, zero_division=0)
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, labels=classes, average="macro", zero_division=0),
        "per_class": {c: {k: report[c][k] for k in ("precision", "recall", "f1-score", "support")}
                      for c in classes},
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=classes).tolist(),
        "labels": classes,
        "abnormal_auc": roc_auc_score((np.asarray(y_true) != normal).astype(int),
                                      1 - proba[:, classes.index(normal)]),
    }
    return _round(out)


def _round(o):
    if isinstance(o, float):
        return round(o, 4)
    if isinstance(o, dict):
        return {k: _round(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_round(v) for v in o]
    return o


def fit_eval(est, X_tr, y_tr, X_te, y_te, classes, normal):
    est = clone(est).fit(X_tr, y_tr)
    p = est.predict_proba(X_te)
    proba = np.zeros((len(X_te), len(classes)))
    for j, c in enumerate(est.classes_):
        proba[:, classes.index(str(c))] = p[:, j]
    pred = np.array(classes)[proba.argmax(axis=1)]
    return est, evaluate(y_te, pred, proba, classes, normal)


def importance_from_gain(est, feature_names, X, y, n=4000) -> list[dict]:
    """Permutation importance on a subsample, grouped so 187 raw samples
    show up as one 'raw waveform' entry next to each engineered feature."""
    from sklearn.inspection import permutation_importance
    if len(X) > n:
        Xs, _, ys, _ = train_test_split(X, y, train_size=n, stratify=y, random_state=RANDOM_STATE)
    else:
        Xs, ys = X, y
    eng = [c for c in feature_names if c in WAVE_ENGINEERED_COLUMNS]
    r = permutation_importance(est, Xs, ys, n_repeats=3, random_state=RANDOM_STATE,
                               scoring="balanced_accuracy", n_jobs=-1)
    imp = dict(zip(feature_names, r.importances_mean))
    std = dict(zip(feature_names, r.importances_std))
    rows = [{"feature": c, "importance": round(float(imp[c]), 5), "std": round(float(std[c]), 5),
             "engineered": True} for c in eng]
    raw_top = sorted(RAW_WAVE_COLUMNS, key=lambda c: -imp[c])[:5]
    rows += [{"feature": c, "importance": round(float(imp[c]), 5), "std": round(float(std[c]), 5),
              "engineered": False} for c in raw_top]
    return sorted(rows, key=lambda d: -d["importance"])[:20]


def run_task(task, X_tr, y_tr, X_te, y_te) -> tuple[dict, dict]:
    classes, normal = TASKS[task]["classes"], TASKS[task]["normal"]
    F_tr, F_te = engineer_waveform_features(X_tr), engineer_waveform_features(X_te)
    res = {"display_name": TASKS[task]["display"], "classes": classes,
           "n_train": int(len(X_tr)), "n_test": int(len(X_te)),
           "train_class_counts": pd.Series(y_tr).value_counts().reindex(classes, fill_value=0).astype(int).to_dict(),
           "test_class_counts": pd.Series(y_te).value_counts().reindex(classes, fill_value=0).astype(int).to_dict(),
           "models": {}, "ablation": {}}
    fitted = {}
    for name, (display, est) in make_models().items():
        t = time.time()
        model, m = fit_eval(est, F_tr, y_tr, F_te, y_te, classes, normal)
        m["train_seconds"] = round(time.time() - t, 1)
        res["models"][name] = {"display_name": display, "test": m}
        fitted[name] = model
        print(f"[{task}] {display:28s} acc={m['accuracy']:.3f} bal_acc={m['balanced_accuracy']:.3f} "
              f"macroF1={m['macro_f1']:.3f} AUC={m['abnormal_auc']:.3f} ({m['train_seconds']}s)")
    # Feature-engineering ablation: engineered features only vs raw samples only vs both
    for label, cols in (("raw_only", RAW_WAVE_COLUMNS), ("engineered_only", WAVE_ENGINEERED_COLUMNS)):
        _, m = fit_eval(make_models()["hgb"][1], F_tr[cols], y_tr, F_te[cols], y_te, classes, normal)
        res["ablation"][label] = {k: m[k] for k in ("accuracy", "balanced_accuracy", "macro_f1", "abnormal_auc")}
    res["ablation"]["raw_plus_engineered"] = {k: res["models"]["hgb"]["test"][k]
                                              for k in ("accuracy", "balanced_accuracy", "macro_f1", "abnormal_auc")}
    print(f"[{task}] ablation (HistGB, balanced acc): raw {res['ablation']['raw_only']['balanced_accuracy']:.3f} | "
          f"engineered only {res['ablation']['engineered_only']['balanced_accuracy']:.3f} | "
          f"both {res['ablation']['raw_plus_engineered']['balanced_accuracy']:.3f}")
    res["models"]["hgb"]["feature_importance"] = importance_from_gain(
        fitted["hgb"], WAVE_MODEL_COLUMNS, F_te, y_te)
    # Average beat shape per class (for the dashboard's EDA chart)
    res["mean_waveform"] = {c: np.round(X_tr[y_tr == c].mean(axis=0), 4).tolist()
                            for c in classes if (y_tr == c).any()}
    return res, fitted


def save(task, res, fitted, trained_at):
    for name, model in fitted.items():
        joblib.dump({"name": name, "task": task, "display_name": res["models"][name]["display_name"],
                     "estimator": model, "feature_names": WAVE_MODEL_COLUMNS,
                     "classes": TASKS[task]["classes"], "metrics": res["models"][name],
                     "trained_at": trained_at},
                    MODEL_DIR / f"waveform_{task}_{name}.pkl", compress=3)


def load(name: str) -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / name, header=None)


def main():
    t0 = time.time()
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    trained_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    metrics = {"trained_at": trained_at, "tasks": {},
               "evaluation_note": "Random beat-level split (no patient ids in these files): "
                                  "optimistic compared with an inter-patient evaluation."}

    # ---------- Option 2: arrhythmia from waveforms (official Kaggle train/test files) ----------
    lm = TASKS["arrhythmia"]["label_map"]
    tr, te = load("mitbih_train.csv"), load("mitbih_test.csv")
    X_tr, y_tr = tr.iloc[:, :187].to_numpy(), tr[187].astype(int).map(lm).to_numpy()
    X_te, y_te = te.iloc[:, :187].to_numpy(), te[187].astype(int).map(lm).to_numpy()
    res, fitted = run_task("arrhythmia", X_tr, y_tr, X_te, y_te)
    res["source"] = "Kaggle ECG Heartbeat Categorization - MIT-BIH (mitbih_train / mitbih_test)"
    metrics["tasks"]["arrhythmia"] = res
    save("arrhythmia", res, fitted, trained_at)
    demo = te.groupby(187, group_keys=False).sample(n=400, random_state=RANDOM_STATE, replace=False) \
        if te[187].value_counts().min() >= 400 else te.sample(3000, random_state=RANDOM_STATE)
    demo.sample(frac=1, random_state=RANDOM_STATE).to_csv(
        SAMPLE_DIR / "arrhythmia_test_sample.csv", header=False, index=False, float_format="%.5f")

    # ---------- Option 3: myocardial infarction from PTB waveforms ----------
    lm = TASKS["mi"]["label_map"]
    ptb = pd.concat([load("ptbdb_normal.csv"), load("ptbdb_abnormal.csv")], ignore_index=True)
    X, y = ptb.iloc[:, :187].to_numpy(), ptb[187].astype(int).map(lm).to_numpy()
    idx_tr, idx_te = train_test_split(np.arange(len(ptb)), test_size=0.2, stratify=y,
                                      random_state=RANDOM_STATE)
    res, fitted = run_task("mi", X[idx_tr], y[idx_tr], X[idx_te], y[idx_te])
    res["source"] = "Kaggle ECG Heartbeat Categorization - PTB Diagnostic (ptbdb_normal / ptbdb_abnormal), 80/20 stratified split"
    metrics["tasks"]["mi"] = res
    save("mi", res, fitted, trained_at)
    ptb.iloc[idx_te].sample(1500, random_state=RANDOM_STATE).to_csv(
        SAMPLE_DIR / "mi_test_sample.csv", header=False, index=False, float_format="%.5f")

    (MODEL_DIR / "waveform_metrics.json").write_text(json.dumps(metrics, indent=2, default=int))
    print(f"Done in {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
