"""Tests for the waveform models (options 2 and 3): features, validation, API, frontend parsing."""

import numpy as np
import pandas as pd
import pytest

from cardio_ml.waveform import (
    N_SAMPLES, TASKS, WAVE_ENGINEERED_COLUMNS, WAVE_MODEL_COLUMNS, WaveformValidationError,
    beat_lengths, engineer_waveform_features, split_signals_and_labels, validate_waveforms,
)
from conftest import MODEL_DIR, make_beat

import dashboard_utils as du


# ---------------- feature engineering ----------------
def test_beat_length_detects_zero_padding():
    X = np.array([make_beat(120), make_beat(80)])
    assert beat_lengths(X).tolist() == [120, 80]


def test_waveform_features_shape_and_finite():
    X = np.array([make_beat(L, seed=L) for L in (60, 100, 150, 187)])
    F = engineer_waveform_features(X)
    assert list(F.columns) == WAVE_MODEL_COLUMNS
    assert len(F) == 4
    assert np.isfinite(F.to_numpy()).all()


def test_shorter_beat_means_higher_estimated_heart_rate():
    F = engineer_waveform_features(np.array([make_beat(150), make_beat(75)]))
    assert F.loc[1, "heart_rate_bpm_est"] > F.loc[0, "heart_rate_bpm_est"]
    assert F.loc[0, "beat_len_ms"] == pytest.approx(150 * 8.0)   # 125 Hz -> 8 ms per sample


def test_fft_band_energies_sum_to_one():
    F = engineer_waveform_features(np.array([make_beat(130)]))
    bands = [c for c in WAVE_ENGINEERED_COLUMNS if c.startswith("fft_")]
    assert F[bands].sum(axis=1).iloc[0] == pytest.approx(1.0, abs=1e-6)


def test_very_short_beat_does_not_crash():
    F = engineer_waveform_features(np.array([make_beat(12)]))
    assert np.isfinite(F.to_numpy()).all()


# ---------------- validation ----------------
def test_valid_waveforms_pass():
    assert validate_waveforms([make_beat()]).shape == (1, N_SAMPLES)


@pytest.mark.parametrize("bad,msg", [
    ([[0.5] * 100], "187 samples"),
    ([], "non-empty"),
    ([[np.nan] + [0.5] * 186], "NaN"),
    ([[5.0] + [0.5] * 186], "scaled"),
    ([[0.3] * 187], "flat"),
])
def test_invalid_waveforms_rejected(bad, msg):
    with pytest.raises(WaveformValidationError, match=msg):
        validate_waveforms(bad)


def test_split_signals_and_labels():
    df = pd.DataFrame([make_beat() + [2.0], make_beat(90) + [0.0]])
    X, y = split_signals_and_labels(df)
    assert X.shape == (2, 187) and y.tolist() == [2, 0]


# ---------------- API ----------------
@pytest.mark.parametrize("task", list(TASKS))
def test_waveform_endpoint_happy_path(client, task):
    signals = [make_beat(150), make_beat(80), make_beat(140)]
    r = client.post(f"/predict-waveform-batch?task={task}&model_type=mock", json={"signals": signals})
    assert r.status_code == 200
    body = r.json()
    assert body["classes"] == TASKS[task]["classes"]
    assert body["summary"]["n_beats"] == 3
    labels = [p["predicted_label"] for p in body["predictions"]]
    normal = TASKS[task]["normal"]
    assert labels[0] == normal and labels[1] != normal        # mock: short beat = abnormal
    assert body["predictions"][1]["risk_score"] > 0.5


def test_waveform_wrong_length_is_422(client):
    r = client.post("/predict-waveform-batch?task=mi&model_type=mock", json={"signals": [[0.5] * 50]})
    assert r.status_code == 422
    assert "187" in str(r.json()["detail"])


def test_waveform_unknown_model_is_400(client):
    r = client.post("/predict-waveform-batch?task=mi&model_type=nope", json={"signals": [make_beat()]})
    assert r.status_code == 400


def test_waveform_unknown_task_is_422(client):
    r = client.post("/predict-waveform-batch?task=cancer&model_type=mock", json={"signals": [make_beat()]})
    assert r.status_code == 422


def test_waveform_batch_logged(client):
    client.post("/predict-waveform-batch?task=mi&model_type=mock",
                json={"signals": [make_beat()], "source_name": "ptb.csv"})
    run = client.get("/history").json()["runs"][0]
    assert run["model_used"] == "waveform-mi:mock" and run["source_name"] == "ptb.csv"


def test_waveform_models_endpoint(client):
    body = client.get("/waveform/models").json()
    assert set(body) == set(TASKS)


# ---------------- frontend helpers ----------------
def test_parse_waveform_csv_with_and_without_labels():
    classes = TASKS["arrhythmia"]["classes"]
    with_lab = pd.DataFrame([make_beat() + [2], make_beat(90) + [0]])
    sig, lab, err = du.parse_waveform_csv(with_lab, classes)
    assert err is None and len(sig) == 2 and lab == ["VEB", "N"]
    sig, lab, err = du.parse_waveform_csv(with_lab.iloc[:, :187], classes)
    assert err is None and lab is None
    _, _, err = du.parse_waveform_csv(pd.DataFrame([[0.1] * 34]), classes)
    assert "187" in err


def test_waveform_payload_accepted_by_api_and_charts_build(client):
    classes = TASKS["mi"]["classes"]
    df = pd.DataFrame([make_beat(L, seed=L) + [int(L < 100)] for L in (150, 80, 140, 70, 160, 90)])
    signals, labels, _ = du.parse_waveform_csv(df, classes)
    resp = client.post("/predict-waveform-batch?task=mi&model_type=mock", json={"signals": signals}).json()
    pred = du.waveform_predictions_frame(resp, labels)
    ev = du.evaluate_against_labels(pred, classes)
    assert ev["accuracy"] == 1.0                                  # mock rule matches the labels
    curves, bands = du.predicted_mean_waveforms(signals, pred, classes)
    du.mean_waveform_chart(curves, "t", bands)
    du.class_count_bar(resp["summary"]["class_counts"], log_scale=True)
    du.waveform_ablation_bar({"raw_only": {"balanced_accuracy": .9},
                              "raw_plus_engineered": {"balanced_accuracy": .95}}, "t")


# ---------------- real serialized waveform models ----------------
@pytest.mark.slow
@pytest.mark.skipif(not any(MODEL_DIR.glob("waveform_*_*.pkl")), reason="waveform models not trained")
def test_real_waveform_models_on_demo_files():
    from pathlib import Path
    from cardio_ml.waveform import load_waveform_registry, predict_waveforms
    reg = load_waveform_registry(MODEL_DIR)
    demo = Path(__file__).resolve().parents[1] / "frontend" / "sample_data" / "waveform"
    for task, fname, floor in (("arrhythmia", "arrhythmia_test_sample.csv", 0.9),
                               ("mi", "mi_test_sample.csv", 0.9)):
        X, y = split_signals_and_labels(pd.read_csv(demo / fname, header=None).head(600))
        res = predict_waveforms(reg[task]["hgb"], X, task)
        truth = [TASKS[task]["label_map"][int(v)] for v in y]
        assert (res["predicted_label"].to_numpy() == np.array(truth)).mean() >= floor
