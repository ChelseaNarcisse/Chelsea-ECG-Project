"""Waveform-based models (Kaggle "ECG Heartbeat Categorization", Kachuee et al.).

Each row is ONE heartbeat as a 187-sample signal (125 Hz, amplitude scaled to
0-1, zero-padded at the end), optionally followed by a label column.

Two separate tasks use this format (kept separate on purpose - no feature
union with the tabular Sakib features):
  * "arrhythmia": MIT-BIH beats -> AAMI classes N, SVEB, VEB, F, Q
  * "mi":         PTB beats     -> Normal vs Myocardial infarction (MI)

Feature engineering turns the raw samples into descriptors of the beat:
  1. Beat length    the segment runs from one R peak to ~1.2 x the median RR,
                    so the un-padded length is a proxy for the RR interval
  2. Amplitude      statistics of the un-padded signal (mean, std, skew, kurtosis ...)
  3. Shape          QRS width near the start, slopes, second peak (T wave) position/height
  4. Frequency      energy in FFT bands (sharp QRS vs slow ST/T changes)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

N_SAMPLES = 187
WAVEFORM_SAMPLING_HZ = 125

TASKS = {
    "arrhythmia": {
        "classes": ["N", "SVEB", "VEB", "F", "Q"],
        "label_map": {0: "N", 1: "SVEB", 2: "VEB", 3: "F", 4: "Q"},
        "normal": "N",
        "display": "Arrhythmia (5 AAMI classes)",
    },
    "mi": {
        "classes": ["Normal", "MI"],
        "label_map": {0: "Normal", 1: "MI"},
        "normal": "Normal",
        "display": "Myocardial infarction (PTB)",
    },
}

RAW_WAVE_COLUMNS = [f"s{i:03d}" for i in range(N_SAMPLES)]
FFT_BANDS_HZ = [(0, 2), (2, 5), (5, 10), (10, 20), (20, 40), (40, 62.5)]

WAVE_ENGINEERED_COLUMNS = [
    "beat_len_samples", "beat_len_ms", "heart_rate_bpm_est",
    "mean", "std", "skew", "kurtosis", "min", "max", "range", "argmin_ms",
    "energy", "mean_abs_diff", "max_slope", "min_slope",
    "qrs_width_ms", "area_first_100ms",
    "t_peak_ms", "t_peak_amp", "st_level", "late_mean",
    *[f"fft_{lo:g}_{hi:g}hz" for lo, hi in FFT_BANDS_HZ],
    "zero_crossings_centered",
]
WAVE_MODEL_COLUMNS = RAW_WAVE_COLUMNS + WAVE_ENGINEERED_COLUMNS


class WaveformValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("; ".join(errors))


def validate_waveforms(X, max_rows: int = 150_000) -> np.ndarray:
    """Check shape and values of a batch of beat signals."""
    try:
        arr = np.asarray(X, dtype=float)
    except (TypeError, ValueError):
        raise WaveformValidationError(["Signals must be numeric."])
    errors = []
    if arr.ndim != 2 or arr.shape[0] == 0:
        raise WaveformValidationError(["Expected a non-empty 2-D batch: one row per beat."])
    if arr.shape[1] != N_SAMPLES:
        raise WaveformValidationError([f"Each beat must have exactly {N_SAMPLES} samples; got {arr.shape[1]}."])
    if arr.shape[0] > max_rows:
        raise WaveformValidationError([f"Batch has {arr.shape[0]} beats; the maximum is {max_rows}."])
    if not np.isfinite(arr).all():
        errors.append(f"{int((~np.isfinite(arr)).any(axis=1).sum())} beat(s) contain NaN or infinite values.")
    elif (arr.min() < -0.05) or (arr.max() > 1.05):
        errors.append("Signals must be min-max scaled to the range [0, 1] (as in the Kaggle files).")
    flat = np.isfinite(arr).all(axis=1) & (np.nanstd(arr, axis=1) == 0)
    if flat.any():
        errors.append(f"{int(flat.sum())} beat(s) are flat lines (no signal).")
    if errors:
        raise WaveformValidationError(errors)
    return arr


def beat_lengths(X: np.ndarray) -> np.ndarray:
    """Number of samples before the zero padding starts (at least 10)."""
    nonzero = X > 1e-6
    last = N_SAMPLES - np.argmax(nonzero[:, ::-1], axis=1)
    return np.clip(last, 10, N_SAMPLES)


def engineer_waveform_features(X: np.ndarray) -> pd.DataFrame:
    """Return the raw samples plus engineered features (WAVE_MODEL_COLUMNS)."""
    X = np.asarray(X, dtype=float)
    n = len(X)
    ms = 1000.0 / WAVEFORM_SAMPLING_HZ
    L = beat_lengths(X)
    mask = np.arange(N_SAMPLES)[None, :] < L[:, None]           # un-padded part
    cnt = mask.sum(axis=1)
    Xm = np.where(mask, X, np.nan)

    f = {}
    f["beat_len_samples"] = L
    f["beat_len_ms"] = L * ms
    f["heart_rate_bpm_est"] = 60000.0 / (L * ms / 1.2)          # segment ~ 1.2 x RR
    mean = np.nanmean(Xm, axis=1)
    std = np.nanstd(Xm, axis=1) + 1e-9
    z = (Xm - mean[:, None]) / std[:, None]
    f["mean"], f["std"] = mean, std
    f["skew"] = np.nanmean(z ** 3, axis=1)
    f["kurtosis"] = np.nanmean(z ** 4, axis=1) - 3
    f["min"], f["max"] = np.nanmin(Xm, axis=1), np.nanmax(Xm, axis=1)
    f["range"] = f["max"] - f["min"]
    f["argmin_ms"] = np.nanargmin(Xm, axis=1) * ms
    f["energy"] = np.nansum(Xm ** 2, axis=1) / cnt

    d = np.diff(X, axis=1)
    dmask = mask[:, 1:]
    dm = np.where(dmask, d, np.nan)
    f["mean_abs_diff"] = np.nanmean(np.abs(dm), axis=1)
    f["max_slope"] = np.nanmax(dm, axis=1)
    f["min_slope"] = np.nanmin(dm, axis=1)

    # QRS width: samples from the start (R peak) until the signal first
    # falls below half of its initial height.
    start = X[:, :1]
    below = X < (start * 0.5)
    first_below = np.where(below.any(axis=1), np.argmax(below, axis=1), L)
    f["qrs_width_ms"] = first_below * ms
    k100 = int(round(100 / ms))
    f["area_first_100ms"] = X[:, :k100].sum(axis=1) * ms / 1000

    # T wave: highest point after the first 150 ms of the beat.
    k150 = int(round(150 / ms))
    late = np.where(mask & (np.arange(N_SAMPLES)[None, :] >= k150), X, -np.inf)
    t_idx = np.argmax(late, axis=1)
    f["t_peak_ms"] = t_idx * ms
    f["t_peak_amp"] = X[np.arange(n), t_idx]
    k_st = slice(int(round(80 / ms)), int(round(160 / ms)))
    f["st_level"] = X[:, k_st].mean(axis=1) - mean
    late_m = np.where(mask & (np.arange(N_SAMPLES)[None, :] >= k150), X, 0.0)
    late_n = (mask & (np.arange(N_SAMPLES)[None, :] >= k150)).sum(axis=1)
    f["late_mean"] = late_m.sum(axis=1) / np.maximum(late_n, 1)   # 0 for beats shorter than 150 ms

    spec = np.abs(np.fft.rfft(np.where(mask, X - mean[:, None], 0.0), axis=1)) ** 2
    freqs = np.fft.rfftfreq(N_SAMPLES, d=1.0 / WAVEFORM_SAMPLING_HZ)
    total = spec.sum(axis=1) + 1e-12
    for lo, hi in FFT_BANDS_HZ:
        band = (freqs >= lo) & (freqs < hi if hi < 62.5 else freqs <= hi)
        f[f"fft_{lo:g}_{hi:g}hz"] = spec[:, band].sum(axis=1) / total

    centered = np.where(mask, X - mean[:, None], 0.0)
    f["zero_crossings_centered"] = (np.diff(np.sign(centered), axis=1) != 0).sum(axis=1)

    eng = pd.DataFrame(f)[WAVE_ENGINEERED_COLUMNS]
    raw = pd.DataFrame(X, columns=RAW_WAVE_COLUMNS)
    out = pd.concat([raw, eng], axis=1)
    return out.replace([np.inf, -np.inf], np.nan).fillna(0.0)


def split_signals_and_labels(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray | None]:
    """A Kaggle waveform CSV has 187 signal columns, optionally + 1 label column."""
    arr = df.to_numpy(dtype=float)
    if arr.shape[1] == N_SAMPLES + 1:
        return arr[:, :N_SAMPLES], arr[:, N_SAMPLES].astype(int)
    return arr, None


def predict_waveforms(bundle, X: np.ndarray, task: str) -> pd.DataFrame:
    """Validate -> engineer features -> predict. One row per beat."""
    from .predictor import risk_tier

    arr = validate_waveforms(X)
    feats = engineer_waveform_features(arr)[bundle.feature_names]
    classes = TASKS[task]["classes"]
    raw = bundle.estimator.predict_proba(feats)
    est_classes = [str(c) for c in bundle.estimator.classes_]
    proba = np.zeros((len(arr), len(classes)))
    for j, c in enumerate(est_classes):
        if c in classes:
            proba[:, classes.index(c)] = raw[:, j]
    normal = TASKS[task]["normal"]
    risk = 1.0 - proba[:, classes.index(normal)]
    labels = np.array(classes)[proba.argmax(axis=1)]
    out = pd.DataFrame({"index": np.arange(len(arr)), "predicted_label": labels,
                        "confidence": proba.max(axis=1), "risk_score": np.round(risk, 4)})
    out["risk_tier"] = [risk_tier(r) for r in out["risk_score"]]
    out["ventricular_alert"] = out["predicted_label"].isin({"VEB", "F"})
    for j, c in enumerate(classes):
        out[f"p_{c}"] = np.round(proba[:, j], 4)
    return out


def summarize_waveforms(results: pd.DataFrame, task: str) -> dict:
    classes = TASKS[task]["classes"]
    counts = results["predicted_label"].value_counts().reindex(classes, fill_value=0)
    tiers = results["risk_tier"].value_counts().reindex(["low", "moderate", "high"], fill_value=0)
    return {
        "n_beats": int(len(results)),
        "class_counts": {k: int(v) for k, v in counts.items()},
        "risk_tier_counts": {k: int(v) for k, v in tiers.items()},
        "mean_risk": float(results["risk_score"].mean()),
        "n_high_risk": int(tiers["high"]),
        "n_ventricular_alerts": int(results["ventricular_alert"].sum()),
        "abnormal_burden_pct": float(100.0 * (results["predicted_label"] != TASKS[task]["normal"]).mean()),
    }


def load_waveform_registry(model_dir) -> dict[str, dict]:
    """{task: {model_name: ModelBundle}} from models/waveform_<task>_<model>.pkl."""
    from pathlib import Path

    import joblib

    from .predictor import ModelBundle

    registry: dict[str, dict] = {task: {} for task in TASKS}
    for path in sorted(Path(model_dir).glob("waveform_*_*.pkl")):
        obj = joblib.load(path)
        registry.setdefault(obj["task"], {})[obj["name"]] = ModelBundle(
            name=obj["name"], estimator=obj["estimator"], feature_names=obj["feature_names"],
            classes=obj["classes"], metrics=obj.get("metrics", {}),
            display_name=obj.get("display_name", obj["name"]))
    return registry
